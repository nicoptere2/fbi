function sig = find_Pattern(pattern, QAC)
  sig = zeros(1, 1);
  for i = 1:size(pattern)
    if(pattern(i) )
end